﻿using Meadow;
using Meadow.Devices;
using Meadow.Foundation;
using Meadow.Foundation.Graphics;
using Meadow.Foundation.Graphics.MicroLayout;
using RelayControl.UI;
using System.Threading.Tasks;

namespace RelayControl
{
    // Change F7FeatherV2 to F7FeatherV1 for V1.x boards
    public class MeadowApp : App<F7CoreComputeV2>
    {
        private IProjectLabHardware projectLab;
        private DisplayScreen screen;
        private Menu _menu;

        public override Task Initialize()
        {
            projectLab = ProjectLab.Create();

            screen = new DisplayScreen(projectLab.Display, RotationType._270Degrees);

            return base.Initialize();
        }

        void ShowMenuScreen()
        {
            var menuItems = new string[]
                {
                    "Item A",
                    "Item B",
                    "Item C",
                    "Item D",
                    "Item E",
                    "Item F",
                };

            _menu = new Menu(menuItems, screen);

            projectLab.UpButton.Clicked += (s, e) => _menu.Up();
            projectLab.DownButton.Clicked += (s, e) => _menu.Down();
        }

        public override Task Run()
        {
            //SplashScreen.Show(screen);

            //Task.Delay(1000);

            //Resolver.Log.Info("splash screen going down.");

            //screen.Controls.Clear();

            //Resolver.Log.Info("cleared screen.");

            ShowMenuScreen();

            return base.Run();
        }
    }
}